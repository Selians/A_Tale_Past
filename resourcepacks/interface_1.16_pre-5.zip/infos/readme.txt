Readme
======

Thanks you for downloading interface texture pack !

The goal of this pack is to be a overlay making Minecraft's interface more ergonomic, textures more coherent, 
while being intended for PVP.
There is also a lot of Optifine features, like GUI animation, RayTracing (specular maps), and emissive textures !

Advice using
------------
Download the last version of Optifine in coincidence with your Minecraft's version (https://optifine.net/downloads).
Download a shader for improve light overlay, i recommend to use SEUS-Renewed Shaders (https://www.sonicether.com/seus/).
Reduce the size of the tchat for more visibility.
All the useful links are in usefull_links.txt.


